# Complex Inferno Parity Cases

Advanced FHIR R4 scenarios for regression testing against Inferno (base FHIR, no profile
selected unless noted). These stress nested structures, bundles, polymorphic fields,
contained resources, and cross-resource references.

| # | File | Resource | Category | Expected |
|---|------|----------|----------|----------|
| C01 | `01-valid-observation-blood-pressure-components.json` | Observation | Valid | Pass — nested `component` array (systolic/diastolic) |
| C02 | `02-valid-patient-contained-organization.json` | Patient | Valid | Pass — `#` contained reference resolution |
| C03 | `03-valid-patient-nested-extensions.json` | Patient | Valid | Pass — multi-level extension nesting |
| C04 | `04-valid-medication-request-complex-dosage.json` | MedicationRequest | Valid | Pass — dosageInstruction, timing, route |
| C05 | `05-valid-diagnostic-report-with-results.json` | DiagnosticReport | Valid | Pass — multiple `result` references |
| C06 | `06-valid-questionnaire-response-nested.json` | QuestionnaireResponse | Valid | Pass — nested `item` / `answer` tree |
| C07 | `07-valid-bundle-searchset-with-links.json` | Bundle | Valid | Pass — searchset type, `link`, `total` |
| C08 | `08-valid-encounter-hospitalization.json` | Encounter | Valid | Pass — class, period, hospitalization, location |
| C09 | `09-valid-observation-value-codeable-concept.json` | Observation | Valid | Pass — polymorphic `valueCodeableConcept` |
| C10 | `10-valid-careplan-multiple-activities.json` | CarePlan | Valid | Pass — activities with detail timing |
| C11 | `11-invalid-observation-dual-value-types.json` | Observation | Invalid | Error — both `valueQuantity` and `valueString` |
| C12 | `12-invalid-observation-component-missing-code.json` | Observation | Invalid | Error — component missing required `code` |
| C13 | `13-invalid-bundle-transaction-broken-reference.json` | Bundle | Invalid | Error — transaction entry references missing resource |
| C14 | `14-invalid-patient-extension-wrong-value-type.json` | Patient | Invalid | Error — extension value type mismatch |
| C15 | `15-stress-clinical-document-bundle.json` | Bundle | Mixed | Errors + warnings — document bundle with valid + invalid nested resources |

Run the same cross-check workflow as the parent suite: upload here, compare counts/messages with Inferno.
