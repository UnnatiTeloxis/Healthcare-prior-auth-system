<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile CDSHooksRequest
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:CDSHooksRequest</sch:title>
    <sch:rule context="f:CDSHooksRequest">
      <sch:assert test="count(f:fhirServer) &gt;= 1">fhirServer: minimum cardinality of 'fhirServer' is 1</sch:assert>
      <sch:assert test="count(f:fhirAuthorization) &gt;= 1">fhirAuthorization: minimum cardinality of 'fhirAuthorization' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
