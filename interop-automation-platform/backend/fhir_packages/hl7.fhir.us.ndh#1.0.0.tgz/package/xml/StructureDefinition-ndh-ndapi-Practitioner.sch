<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile NdhPractitioner
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Practitioner</sch:title>
    <sch:rule context="f:Practitioner">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-race|6.1.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-race|6.1.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity|6.1.0']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity|6.1.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/individual-genderIdentity']) &lt;= 0">extension with URL = 'http://hl7.org/fhir/StructureDefinition/individual-genderIdentity': maximum cardinality of 'extension' is 0</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/individual-pronouns']) &lt;= 0">extension with URL = 'http://hl7.org/fhir/StructureDefinition/individual-pronouns': maximum cardinality of 'extension' is 0</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/individual-recordedSexOrGender']) &lt;= 0">extension with URL = 'http://hl7.org/fhir/StructureDefinition/individual-recordedSexOrGender': maximum cardinality of 'extension' is 0</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-verification-status']) &gt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-verification-status': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-verification-status']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-verification-status': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:meta</sch:title>
    <sch:rule context="f:Practitioner/f:meta">
      <sch:assert test="count(f:profile) &gt;= 1">profile: minimum cardinality of 'profile' is 1</sch:assert>
      <sch:assert test="count(f:profile) &lt;= 1">profile: maximum cardinality of 'profile' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:extension</sch:title>
    <sch:rule context="f:Practitioner/f:extension">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:url) &gt;= 1">url: minimum cardinality of 'url' is 1</sch:assert>
      <sch:assert test="count(f:url) &lt;= 1">url: maximum cardinality of 'url' is 1</sch:assert>
      <sch:assert test="count(f:value[x]) &gt;= 1">value[x]: minimum cardinality of 'value[x]' is 1</sch:assert>
      <sch:assert test="count(f:value[x]) &lt;= 1">value[x]: maximum cardinality of 'value[x]' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:identifier</sch:title>
    <sch:rule context="f:Practitioner/f:identifier">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status']) &gt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:name</sch:title>
    <sch:rule context="f:Practitioner/f:name">
      <sch:assert test="count(f:given) &gt;= 1">given: minimum cardinality of 'given' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:telecom</sch:title>
    <sch:rule context="f:Practitioner/f:telecom">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-via-intermediary']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-via-intermediary': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:system) &gt;= 1">system: minimum cardinality of 'system' is 1</sch:assert>
      <sch:assert test="count(f:value) &gt;= 1">value: minimum cardinality of 'value' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:address</sch:title>
    <sch:rule context="f:Practitioner/f:address">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/geolocation|4.0.1']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/StructureDefinition/geolocation|4.0.1': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:qualification</sch:title>
    <sch:rule context="f:Practitioner/f:qualification">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-practitioner-qualification']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-practitioner-qualification': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:qualification/f:identifier</sch:title>
    <sch:rule context="f:Practitioner/f:qualification/f:identifier">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status']) &gt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-identifier-status': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Practitioner/f:communication</sch:title>
    <sch:rule context="f:Practitioner/f:communication">
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-communication-proficiency']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/us/ndh/StructureDefinition/base-ext-communication-proficiency': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
