<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile GraphDefinition
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link</sch:title>
    <sch:rule context="f:GraphDefinition/f:link">
      <sch:assert test="count(f:path) &gt;= 1">path: minimum cardinality of 'path' is 1</sch:assert>
      <sch:assert test="count(f:path) &gt;= 1">path: minimum cardinality of 'path' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link/f:target/f:link</sch:title>
    <sch:rule context="f:GraphDefinition/f:link/f:target/f:link">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:path) &lt;= 1">path: maximum cardinality of 'path' is 1</sch:assert>
      <sch:assert test="count(f:sliceName) &lt;= 1">sliceName: maximum cardinality of 'sliceName' is 1</sch:assert>
      <sch:assert test="count(f:min) &lt;= 1">min: maximum cardinality of 'min' is 1</sch:assert>
      <sch:assert test="count(f:max) &lt;= 1">max: maximum cardinality of 'max' is 1</sch:assert>
      <sch:assert test="count(f:description) &lt;= 1">description: maximum cardinality of 'description' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link/f:target/f:link/f:target</sch:title>
    <sch:rule context="f:GraphDefinition/f:link/f:target/f:link/f:target">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:type) &gt;= 1">type: minimum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:type) &lt;= 1">type: maximum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:params) &lt;= 1">params: maximum cardinality of 'params' is 1</sch:assert>
      <sch:assert test="count(f:profile) &lt;= 1">profile: maximum cardinality of 'profile' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link/f:target/f:link/f:target/f:compartment</sch:title>
    <sch:rule context="f:GraphDefinition/f:link/f:target/f:link/f:target/f:compartment">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:use) &gt;= 1">use: minimum cardinality of 'use' is 1</sch:assert>
      <sch:assert test="count(f:use) &lt;= 1">use: maximum cardinality of 'use' is 1</sch:assert>
      <sch:assert test="count(f:code) &gt;= 1">code: minimum cardinality of 'code' is 1</sch:assert>
      <sch:assert test="count(f:code) &lt;= 1">code: maximum cardinality of 'code' is 1</sch:assert>
      <sch:assert test="count(f:rule) &gt;= 1">rule: minimum cardinality of 'rule' is 1</sch:assert>
      <sch:assert test="count(f:rule) &lt;= 1">rule: maximum cardinality of 'rule' is 1</sch:assert>
      <sch:assert test="count(f:expression) &lt;= 1">expression: maximum cardinality of 'expression' is 1</sch:assert>
      <sch:assert test="count(f:description) &lt;= 1">description: maximum cardinality of 'description' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link/f:target/f:link/f:target/f:link</sch:title>
    <sch:rule context="f:GraphDefinition/f:link/f:target/f:link/f:target/f:link">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:path) &lt;= 1">path: maximum cardinality of 'path' is 1</sch:assert>
      <sch:assert test="count(f:sliceName) &lt;= 1">sliceName: maximum cardinality of 'sliceName' is 1</sch:assert>
      <sch:assert test="count(f:min) &lt;= 1">min: maximum cardinality of 'min' is 1</sch:assert>
      <sch:assert test="count(f:max) &lt;= 1">max: maximum cardinality of 'max' is 1</sch:assert>
      <sch:assert test="count(f:description) &lt;= 1">description: maximum cardinality of 'description' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link/f:target/f:link/f:target/f:link/f:target</sch:title>
    <sch:rule context="f:GraphDefinition/f:link/f:target/f:link/f:target/f:link/f:target">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:type) &gt;= 1">type: minimum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:type) &lt;= 1">type: maximum cardinality of 'type' is 1</sch:assert>
      <sch:assert test="count(f:params) &lt;= 1">params: maximum cardinality of 'params' is 1</sch:assert>
      <sch:assert test="count(f:profile) &lt;= 1">profile: maximum cardinality of 'profile' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:GraphDefinition/f:link/f:target/f:link/f:target/f:link/f:target/f:compartment</sch:title>
    <sch:rule context="f:GraphDefinition/f:link/f:target/f:link/f:target/f:link/f:target/f:compartment">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:use) &gt;= 1">use: minimum cardinality of 'use' is 1</sch:assert>
      <sch:assert test="count(f:use) &lt;= 1">use: maximum cardinality of 'use' is 1</sch:assert>
      <sch:assert test="count(f:code) &gt;= 1">code: minimum cardinality of 'code' is 1</sch:assert>
      <sch:assert test="count(f:code) &lt;= 1">code: maximum cardinality of 'code' is 1</sch:assert>
      <sch:assert test="count(f:rule) &gt;= 1">rule: minimum cardinality of 'rule' is 1</sch:assert>
      <sch:assert test="count(f:rule) &lt;= 1">rule: maximum cardinality of 'rule' is 1</sch:assert>
      <sch:assert test="count(f:expression) &lt;= 1">expression: maximum cardinality of 'expression' is 1</sch:assert>
      <sch:assert test="count(f:description) &lt;= 1">description: maximum cardinality of 'description' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
